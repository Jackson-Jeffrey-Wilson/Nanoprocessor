## Clock signal
set_property PACKAGE_PIN W5 [get_ports Clk]
set_property IOSTANDARD LVCMOS33 [get_ports Clk]
create_clock -add -name sys_clk_pin -period 10.00 -waveform {0 5} [get_ports Clk]

## Reset - Centre Button
set_property PACKAGE_PIN U18 [get_ports Reset]
set_property IOSTANDARD LVCMOS33 [get_ports Reset]

## R7 output - LED 0 to LED 3
set_property PACKAGE_PIN U16 [get_ports {R7[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {R7[0]}]
set_property PACKAGE_PIN E19 [get_ports {R7[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {R7[1]}]
set_property PACKAGE_PIN U19 [get_ports {R7[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {R7[2]}]
set_property PACKAGE_PIN V19 [get_ports {R7[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {R7[3]}]

## Zero flag - LED 14
set_property PACKAGE_PIN V14 [get_ports Zero]
set_property IOSTANDARD LVCMOS33 [get_ports Zero]

## Overflow flag - LED 15
set_property PACKAGE_PIN V3 [get_ports Overflow]
set_property IOSTANDARD LVCMOS33 [get_ports Overflow]

## 7 Segment Display - Segments
set_property PACKAGE_PIN W7 [get_ports {Seg7_out[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Seg7_out[0]}]
set_property PACKAGE_PIN W6 [get_ports {Seg7_out[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Seg7_out[1]}]
set_property PACKAGE_PIN U8 [get_ports {Seg7_out[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Seg7_out[2]}]
set_property PACKAGE_PIN V8 [get_ports {Seg7_out[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Seg7_out[3]}]
set_property PACKAGE_PIN U5 [get_ports {Seg7_out[4]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Seg7_out[4]}]
set_property PACKAGE_PIN V5 [get_ports {Seg7_out[5]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Seg7_out[5]}]
set_property PACKAGE_PIN U7 [get_ports {Seg7_out[6]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Seg7_out[6]}]

## 7 Segment Display - Anodes
set_property PACKAGE_PIN U2 [get_ports {Anode[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Anode[0]}]
set_property PACKAGE_PIN U4 [get_ports {Anode[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Anode[1]}]
set_property PACKAGE_PIN V4 [get_ports {Anode[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Anode[2]}]
set_property PACKAGE_PIN W4 [get_ports {Anode[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Anode[3]}]
