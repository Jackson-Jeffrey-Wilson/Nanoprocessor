library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_Nanoprocessor_Basic is
end TB_Nanoprocessor_Basic;

architecture Behavioral of TB_Nanoprocessor_Basic is

    component Nanoprocessor_Basic
        Port (
            Clk      : in  STD_LOGIC;
            Reset    : in  STD_LOGIC;
            Overflow : out STD_LOGIC;
            Zero     : out STD_LOGIC;
            R7       : out STD_LOGIC_VECTOR(3 downto 0);
            Seg7_out : out STD_LOGIC_VECTOR(6 downto 0);
            Anode    : out STD_LOGIC_VECTOR(3 downto 0)
        );
    end component;

    signal Clk_TB      : STD_LOGIC := '0';
    signal Reset_TB    : STD_LOGIC := '0';
    signal Overflow_TB : STD_LOGIC;
    signal Zero_TB     : STD_LOGIC;
    signal R7_TB       : STD_LOGIC_VECTOR(3 downto 0);
    signal Seg7_TB     : STD_LOGIC_VECTOR(6 downto 0);
    signal Anode_TB    : STD_LOGIC_VECTOR(3 downto 0);

begin

    UUT : Nanoprocessor_Basic
        port map (
            Clk      => Clk_TB,
            Reset    => Reset_TB,
            Overflow => Overflow_TB,
            Zero     => Zero_TB,
            R7       => R7_TB,
            Seg7_out => Seg7_TB,
            Anode    => Anode_TB
        );

    Clk_TB <= not Clk_TB after 2 ns;

    process
    begin
        Reset_TB <= '1';
        wait for 30 ns;
        Reset_TB <= '0';

        wait for 500 ns;

        Reset_TB <= '1';
        wait for 30 ns;
        Reset_TB <= '0';

        wait for 500 ns;

        Reset_TB <= '1';
        wait for 50 ns;

        wait;
    end process;

end Behavioral;