library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity MUX_2_way_3_Bit is
Port (
Adder_out : in STD_LOGIC_VECTOR (2 downto 0);
Address : in STD_LOGIC_VECTOR (2 downto 0);
Jump : in STD_LOGIC;
Q : out STD_LOGIC_VECTOR (2 downto 0)
);
end MUX_2_way_3_Bit;

architecture Behavioral of MUX_2_way_3_Bit is
begin
process(Adder_out, Address, Jump)
begin
case Jump is
when '0' => Q <= Adder_out;
when others => Q <= Address;
end case;
end process;
end Behavioral;
