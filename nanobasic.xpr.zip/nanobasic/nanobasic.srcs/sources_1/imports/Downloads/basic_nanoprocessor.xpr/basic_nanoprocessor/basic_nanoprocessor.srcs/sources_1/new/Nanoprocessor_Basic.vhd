library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Nanoprocessor_Basic is
Port (
    Clk : in STD_LOGIC;
    Reset : in STD_LOGIC;
    Overflow : out STD_LOGIC;
    Zero : out STD_LOGIC;
    R7 : out STD_LOGIC_VECTOR (3 downto 0);
    Seg7_out : out STD_LOGIC_VECTOR (6 downto 0);
    Anode : out STD_LOGIC_VECTOR (3 downto 0)
);
end Nanoprocessor_Basic;

architecture Behavioral of Nanoprocessor_Basic is

component LUT_16_7
port(
    Data : IN STD_LOGIC_VECTOR (3 DOWNTO 0);
    Seg7_out : OUT STD_LOGIC_VECTOR (6 DOWNTO 0);
    Anode : OUT STD_LOGIC_VECTOR (3 DOWNTO 0)
);
end component;

component Slow_Clk
Port (
    Clk_in : in STD_LOGIC;
    Clk_out : out STD_LOGIC
);
end component;

component Register_Bank
Port(
    Reg_en : in STD_LOGIC_VECTOR (2 downto 0);
    Clk : in STD_LOGIC;
    Reset : in STD_LOGIC;
    Inp : in STD_LOGIC_VECTOR (3 downto 0);
    Q0,Q1,Q2,Q3,Q4,Q5,Q6,Q7 : out STD_LOGIC_VECTOR (3 downto 0)
);
end component;

component MUX_8_way_4_Bit
Port(
    Reg_Sel : in STD_LOGIC_VECTOR (2 downto 0);
    R0,R1,R2,R3,R4,R5,R6,R7 : in STD_LOGIC_VECTOR (3 downto 0);
    Q : out STD_LOGIC_VECTOR (3 downto 0)
);
end component;

component Add_Sub_Unit
Port(
    A : in STD_LOGIC_VECTOR (3 downto 0);
    B : in STD_LOGIC_VECTOR (3 downto 0);
    Sel : in STD_LOGIC;
    En : in STD_LOGIC;
    S : out STD_LOGIC_VECTOR (3 downto 0);
    C_out : out STD_LOGIC;
    Z_out : out STD_LOGIC
);
end component;

component MUX_2_way_4_Bit
Port(
    Adder_Sub_Out : in STD_LOGIC_VECTOR (3 downto 0);
    Imd_Value : in STD_LOGIC_VECTOR (3 downto 0);
    Load : in STD_LOGIC;
    Q : out STD_LOGIC_VECTOR (3 downto 0)
);
end component;

component MUX_2_way_3_Bit
Port(
    Adder_out : in STD_LOGIC_VECTOR (2 downto 0);
    Address : in STD_LOGIC_VECTOR (2 downto 0);
    Jump : in STD_LOGIC;
    Q : out STD_LOGIC_VECTOR (2 downto 0)
);
end component;

component Instruction_Decoder
Port(
    Instruction : in STD_LOGIC_VECTOR (11 downto 0);
    Reg_Check_Jmp : in STD_LOGIC_VECTOR (3 downto 0);
    Reg_en : out STD_LOGIC_VECTOR (2 downto 0);
    Load_sel : out STD_LOGIC;
    Imd_Val : out STD_LOGIC_VECTOR (3 downto 0);
    Reg_Sel_A : out STD_LOGIC_VECTOR (2 downto 0);
    Reg_Sel_B : out STD_LOGIC_VECTOR (2 downto 0);
    Add_Sub_Sel : out STD_LOGIC;
    Jump_address : out STD_LOGIC_VECTOR (2 downto 0);
    Jump_flag : out STD_LOGIC
);
end component;

component Program_ROM
Port(
    address : in STD_LOGIC_VECTOR (2 downto 0);
    data : out STD_LOGIC_VECTOR (11 downto 0)
);
end component;

component Program_Counter
Port(
    D : in STD_LOGIC_VECTOR (2 downto 0);
    En : in STD_LOGIC;
    Reset : in STD_LOGIC;
    Clk : in STD_LOGIC;
    Q : out STD_LOGIC_VECTOR (2 downto 0)
);
end component;

component Adder_3_Bit
Port(
    A : in STD_LOGIC_VECTOR (2 downto 0);
    C_in : in STD_LOGIC;
    S : out STD_LOGIC_VECTOR (2 downto 0);
    C_out : out STD_LOGIC
);
end component;


signal Imd_Val, Add_Sub_Out, Data_Mux_to_Reg_Bank : std_logic_vector(3 downto 0);
signal Data_bus0, Data_bus1, Data_bus2, Data_bus3,
       Data_bus4, Data_bus5, Data_bus6, Data_bus7 : std_logic_vector(3 downto 0);

signal Ins_Bus : STD_LOGIC_VECTOR(11 downto 0);

signal Mem_Bus, Reg_SelA, Reg_SelB, Count_Mux_to_PC,
       Mem_RCA3_to_Mux, Jump_Add : STD_LOGIC_VECTOR (2 downto 0);

signal Reg_bus : STD_LOGIC_VECTOR(2 downto 0);

signal Add_Sub_Sel, Load_Select, Jump_Flag : STD_LOGIC;

signal slow_clock : STD_LOGIC;

signal Mux_A_out, Mux_B_out : std_logic_vector(3 downto 0);

signal Carry_Flag, Zero_Flag : std_logic;


begin

LUT_16_7_0 : LUT_16_7
port map(
    Data => Data_bus7,
    Seg7_out => Seg7_out,
    Anode => Anode
);

Slow_Clk_0 : Slow_Clk
port map (
    Clk_in => Clk,
    Clk_out => slow_clock
);

Program_ROM_0 : Program_ROM
port map (
    address => Mem_Bus,
    data => Ins_Bus
);


Program_Counter_0 : Program_Counter
port map (
    D => Count_Mux_to_PC,
    En => '1',
    Reset => Reset,
    Clk => slow_clock,
    Q => Mem_Bus
);

Instuction_Decoder_0 : Instruction_Decoder
port map (
    Instruction => Ins_Bus,
    Reg_en => Reg_bus,
    Load_sel => Load_Select,
    Imd_Val => Imd_Val,
    Reg_Sel_A => Reg_SelA,
    Reg_Sel_B => Reg_SelB,
    Add_Sub_Sel => Add_Sub_Sel,
    Jump_address => Jump_Add,
    Jump_flag => Jump_Flag,
    Reg_Check_Jmp => Mux_A_out
);

Register_Bank_0 : Register_Bank
port map (
    Reg_en => Reg_bus,
    Clk => slow_clock,
    Reset => Reset,
    Inp => Data_Mux_to_Reg_Bank,
    Q0 => Data_bus0,
    Q1 => Data_bus1,
    Q2 => Data_bus2,
    Q3 => Data_bus3,
    Q4 => Data_bus4,
    Q5 => Data_bus5,
    Q6 => Data_bus6,
    Q7 => Data_bus7
);

Add_Sub_Unit_0 : Add_Sub_Unit
port map (
    A => Mux_A_out,
    B => Mux_B_out,
    Sel => Add_Sub_Sel,
    En => '1',
    S => Add_Sub_Out,
    C_out => Carry_Flag,
    Z_out => Zero_Flag
);

MUX_2_way_4_Bit_0 : MUX_2_way_4_Bit
port map (
    Load => Load_Select,
    Adder_Sub_Out => Add_Sub_Out,
    Imd_Value => Imd_Val,
    Q => Data_Mux_to_Reg_Bank
);

MUX_8_way_4_Bit_A : MUX_8_way_4_Bit
port map (
    Reg_Sel => Reg_SelA,
    R0 => Data_bus0,
    R1 => Data_bus1,
    R2 => Data_bus2,
    R3 => Data_bus3,
    R4 => Data_bus4,
    R5 => Data_bus5,
    R6 => Data_bus6,
    R7 => Data_bus7,
    Q => Mux_A_out
);

MUX_8_way_4_Bit_B : MUX_8_way_4_Bit
port map (
    Reg_Sel => Reg_SelB,
    R0 => Data_bus0,
    R1 => Data_bus1,
    R2 => Data_bus2,
    R3 => Data_bus3,
    R4 => Data_bus4,
    R5 => Data_bus5,
    R6 => Data_bus6,
    R7 => Data_bus7,
    Q => Mux_B_out
);

Adder_3_Bit_0 : Adder_3_Bit
port map (
    A => Mem_Bus,
    C_in => '0',
    S => Mem_RCA3_to_Mux,
    C_out => open
);

MUX_2_way_3_Bit_0 : MUX_2_way_3_Bit
port map (
    Jump => Jump_Flag,
    Adder_out => Mem_RCA3_to_Mux,
    Address => Jump_Add,
    Q => Count_Mux_to_PC
);

Overflow <= Carry_Flag;
Zero <= Zero_Flag;
R7 <= Data_bus7;

end Behavioral;