library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity LUT_16_7 is
PORT (
Data : IN STD_LOGIC_VECTOR (3 DOWNTO 0);
Seg7_Out : OUT STD_LOGIC_VECTOR (6 DOWNTO 0);
Anode : OUT STD_LOGIC_VECTOR (3 DOWNTO 0)
);
END LUT_16_7;

architecture Behavioral of LUT_16_7 is

type rom_type is array (0 to 15) of STD_LOGIC_VECTOR(6 downto 0);

signal LUT_16_7_ROM : rom_type := (
"1000000","1111001","0100100","0110000",
"0011001","0010010","0000010","1111000",
"0000000","0010000","0001000","0000011",
"1000110","0100001","0000110","0001110"
);

begin
Seg7_Out <= LUT_16_7_ROM(to_integer(unsigned(Data)));
Anode <= "1110";
end Behavioral;