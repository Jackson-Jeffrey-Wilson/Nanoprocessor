library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity MUX_2_way_4_Bit is
Port (
Adder_Sub_Out : in STD_LOGIC_VECTOR (3 downto 0);
Imd_Value : in STD_LOGIC_VECTOR (3 downto 0);
Load : in STD_LOGIC;
Q : out STD_LOGIC_VECTOR (3 downto 0)
);
end MUX_2_way_4_Bit;

architecture Behavioral of MUX_2_way_4_Bit is
begin
process(Adder_Sub_Out, Imd_Value, Load)
begin
case Load is
when '0' => Q <= Adder_Sub_Out;
when others => Q <= Imd_Value;
end case;
end process;
end Behavioral;
