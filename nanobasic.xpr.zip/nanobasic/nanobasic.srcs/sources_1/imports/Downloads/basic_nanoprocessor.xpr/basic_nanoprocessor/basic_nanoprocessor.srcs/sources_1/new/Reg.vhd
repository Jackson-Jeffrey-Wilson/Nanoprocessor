library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Reg is
Port (
    D : in STD_LOGIC_VECTOR (3 downto 0);
    En : in STD_LOGIC;
    Clk : in STD_LOGIC;
    Reset : in STD_LOGIC;
    Q : out STD_LOGIC_VECTOR (3 downto 0)
);
end Reg;

architecture Behavioral of Reg is
signal reg_data : STD_LOGIC_VECTOR (3 downto 0) := (others => '0');

begin

process(Clk)
begin
    if rising_edge(Clk) then
        if Reset = '1' then
            reg_data <= (others => '0');
        elsif En = '1' then
            reg_data <= D;
        end if;
    end if;
end process;

Q <= reg_data;

end Behavioral;