library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Add_Sub_Unit is
Port (
    A : in STD_LOGIC_VECTOR (3 downto 0);
    B : in STD_LOGIC_VECTOR (3 downto 0);
    Sel : in STD_LOGIC; -- 0 = ADD, 1 = SUB
    En : in STD_LOGIC;
    S : out STD_LOGIC_VECTOR (3 downto 0);
    C_out : out STD_LOGIC;
    Z_out : out STD_LOGIC
);
end Add_Sub_Unit;
 
architecture Behavioral of Add_Sub_Unit is
begin
process(A, B, Sel, En)
    variable temp_res : unsigned(4 downto 0); 
begin
    if En = '1' then 
        if Sel = '0' then
            temp_res := ('0' & unsigned(A)) + ('0' & unsigned(B));
        else
            temp_res := ('0' & unsigned(A)) - ('0' & unsigned(B));
        end if;

        S     <= std_logic_vector(temp_res(3 downto 0));
        C_out <= temp_res(4);
        
        if temp_res(3 downto 0) = "0000" then
            Z_out <= '1';
        else
            Z_out <= '0';
        end if;
    else
        S     <= (others => '0');
        C_out <= '0';
        Z_out <= '0';
    end if;
end process;
end Behavioral;