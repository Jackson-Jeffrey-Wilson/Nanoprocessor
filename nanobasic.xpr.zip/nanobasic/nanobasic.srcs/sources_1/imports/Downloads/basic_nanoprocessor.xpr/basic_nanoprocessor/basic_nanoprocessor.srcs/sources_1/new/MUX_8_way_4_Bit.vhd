library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity MUX_8_way_4_Bit is
Port (
Reg_Sel : in STD_LOGIC_VECTOR (2 downto 0);
R0,R1,R2,R3,R4,R5,R6,R7 : in STD_LOGIC_VECTOR (3 downto 0);
Q : out STD_LOGIC_VECTOR (3 downto 0)
);
end MUX_8_way_4_Bit;

architecture Behavioral of MUX_8_way_4_Bit is
begin
process(Reg_Sel, R0,R1,R2,R3,R4,R5,R6,R7)
begin
case Reg_Sel is
when "000" => Q <= R0;
when "001" => Q <= R1;
when "010" => Q <= R2;
when "011" => Q <= R3;
when "100" => Q <= R4;
when "101" => Q <= R5;
when "110" => Q <= R6;
when others => Q <= R7;
end case;
end process;
end Behavioral;