library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Decoder_3_to_8 is
Port ( I : in STD_LOGIC_VECTOR (2 downto 0);
       EN : in STD_LOGIC;
       Y : out STD_LOGIC_VECTOR (7 downto 0));
end Decoder_3_to_8;

architecture Behavioral of Decoder_3_to_8 is
begin
process(I, EN)
begin
    Y <= (others => '0');
    if EN = '1' then
        Y(to_integer(unsigned(I))) <= '1';
    end if;
end process;
end Behavioral;