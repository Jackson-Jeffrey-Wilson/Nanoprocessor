library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Program_Counter is
    Port ( D : in STD_LOGIC_VECTOR (2 downto 0);
           En : in STD_LOGIC;
           Reset : in STD_LOGIC;
           Clk : in STD_LOGIC;
           Q : out STD_LOGIC_VECTOR (2 downto 0));
end Program_Counter;

architecture Behavioral of Program_Counter is
signal PC : STD_LOGIC_VECTOR(2 downto 0) := (others => '0'); 

begin 

    process (Clk) 
    begin 
        if rising_edge(Clk) then 
            if Reset = '1' then 
                PC <= (others => '0'); 
            elsif En = '1' then 
                PC <= D;              
            end if; 
        end if; 
    end process; 

    Q <= PC; 

end Behavioral;