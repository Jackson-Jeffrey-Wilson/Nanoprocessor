library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Program_ROM is
    Port ( address : in  STD_LOGIC_VECTOR(2 downto 0);
           data    : out STD_LOGIC_VECTOR(11 downto 0));
end Program_ROM;

architecture Behavioral of Program_ROM is

    type rom_type is array (0 to 7) of std_logic_vector(11 downto 0);

    signal ROM_DATA : rom_type := (
        0 => "101110000001",
        1 => "101010000010",
        2 => "101000000011",
        3 => "001111010000",
        4 => "001111000000",
        5 => "000000000000",
        6 => "000000000000",
        7 => "000000000000"
    );

begin

    data <= ROM_DATA(to_integer(unsigned(address)));

end Behavioral;