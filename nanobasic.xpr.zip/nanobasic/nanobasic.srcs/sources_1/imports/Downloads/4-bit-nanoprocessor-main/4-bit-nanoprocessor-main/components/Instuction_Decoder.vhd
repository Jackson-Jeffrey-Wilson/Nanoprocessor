library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Instruction_Decoder is
    Port ( 
        Instruction   : in  STD_LOGIC_VECTOR (11 downto 0);
        Reg_Check_Jmp : in  STD_LOGIC_VECTOR (3 downto 0);
        Reg_en        : out STD_LOGIC_VECTOR (2 downto 0);
        Load_sel      : out STD_LOGIC;
        Imd_Val       : out STD_LOGIC_VECTOR (3 downto 0);
        Reg_Sel_A     : out STD_LOGIC_VECTOR (2 downto 0);
        Reg_Sel_B     : out STD_LOGIC_VECTOR (2 downto 0);
        Add_Sub_Sel   : out STD_LOGIC;
        Jump_address  : out STD_LOGIC_VECTOR (2 downto 0);
        Jump_flag     : out STD_LOGIC
    );
end Instruction_Decoder;

architecture Behavioral of Instruction_Decoder is
begin
    process(Instruction, Reg_Check_Jmp)
    begin
        Reg_en       <= "000";
        Load_sel     <= '0';
        Imd_Val      <= "0000";
        Reg_Sel_A    <= "000";
        Reg_Sel_B    <= "000";
        Add_Sub_Sel  <= '0';
        Jump_address <= "000";
        Jump_flag    <= '0';

        case Instruction(11 downto 10) is

            when "00" => 
                Reg_en      <= Instruction(9 downto 7);
                Reg_Sel_A   <= Instruction(9 downto 7);
                Reg_Sel_B   <= Instruction(6 downto 4);

            when "01" => 
                Reg_en      <= Instruction(9 downto 7);
                Reg_Sel_A   <= "000";                    
                Reg_Sel_B   <= Instruction(9 downto 7);
                Add_Sub_Sel <= '1';                      

            when "10" =>
                Reg_en   <= Instruction(9 downto 7);
                Imd_Val  <= Instruction(3 downto 0);
                Load_sel <= '1';

            when "11" => 
                Reg_Sel_B    <= Instruction(9 downto 7);
                Jump_address <= Instruction(2 downto 0);
                if (Reg_Check_Jmp = "0000") then
                    Jump_flag <= '1';
                else
                    Jump_flag <= '0';
                end if;

            when others =>
                null;

        end case;
    end process;
end Behavioral;