library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity TB_Nanoprocessor_Advance is
end TB_Nanoprocessor_Advance;

architecture Behavioral of TB_Nanoprocessor_Advance is

    component Nanoprocessor_Advance
        Port (
            Clk         : in  STD_LOGIC;
            Reset       : in  STD_LOGIC;
            Overflow    : out STD_LOGIC;
            Zero        : out STD_LOGIC;
            Equal       : out STD_LOGIC;
            Less        : out STD_LOGIC;
            Greater     : out STD_LOGIC;
            Mult_Result : out STD_LOGIC;
            Mult_OV     : out STD_LOGIC;
            Even_Parity : out STD_LOGIC;
            Odd_Parity  : out STD_LOGIC;
            Is_Zero     : out STD_LOGIC;
            Is_Small    : out STD_LOGIC;
            Is_Large    : out STD_LOGIC;
            R7          : out STD_LOGIC_VECTOR (3 downto 0);
            Seg7_out    : out STD_LOGIC_VECTOR (6 downto 0);
            Anode       : out STD_LOGIC_VECTOR (3 downto 0)
        );
    end component;

    signal Clk_TB         : STD_LOGIC := '0';
    signal Reset_TB       : STD_LOGIC := '1';
    signal Overflow_TB    : STD_LOGIC;
    signal Zero_TB        : STD_LOGIC;
    signal Equal_TB       : STD_LOGIC;
    signal Less_TB        : STD_LOGIC;
    signal Greater_TB     : STD_LOGIC;
    signal Mult_Result_TB : STD_LOGIC;
    signal Mult_OV_TB     : STD_LOGIC;
    signal Even_TB        : STD_LOGIC;
    signal Odd_TB         : STD_LOGIC;
    signal IsZero_TB      : STD_LOGIC;
    signal IsSmall_TB     : STD_LOGIC;
    signal IsLarge_TB     : STD_LOGIC;
    signal R7_TB          : STD_LOGIC_VECTOR(3 downto 0);
    signal Seg7_TB        : STD_LOGIC_VECTOR(6 downto 0);
    signal Anode_TB       : STD_LOGIC_VECTOR(3 downto 0);

    constant CLK_PERIOD : time := 10 ns;
    constant SLOW_TICK  : time := 40 ns;

begin

    UUT : Nanoprocessor_Advance
        port map (
            Clk         => Clk_TB,
            Reset       => Reset_TB,
            Overflow    => Overflow_TB,
            Zero        => Zero_TB,
            Equal       => Equal_TB,
            Less        => Less_TB,
            Greater     => Greater_TB,
            Mult_Result => Mult_Result_TB,
            Mult_OV     => Mult_OV_TB,
            Even_Parity => Even_TB,
            Odd_Parity  => Odd_TB,
            Is_Zero     => IsZero_TB,
            Is_Small    => IsSmall_TB,
            Is_Large    => IsLarge_TB,
            R7          => R7_TB,
            Seg7_out    => Seg7_TB,
            Anode       => Anode_TB
        );

    Clk_TB <= not Clk_TB after CLK_PERIOD / 2;

    process
    begin

        Reset_TB <= '1';
        wait for 100 ns;
        Reset_TB <= '0';
        wait for SLOW_TICK * 2;

        wait for SLOW_TICK * 8;

        Reset_TB <= '1';
        wait for 50 ns;
        Reset_TB <= '0';
        wait for SLOW_TICK * 8;

        Reset_TB <= '1';
        wait for 50 ns;
        Reset_TB <= '0';
        wait for SLOW_TICK * 8;

        wait for SLOW_TICK * 24;

        Reset_TB <= '1';
        wait for 50 ns;
        Reset_TB <= '0';
        wait for SLOW_TICK * 10;

        wait;
    end process;

end Behavioral;