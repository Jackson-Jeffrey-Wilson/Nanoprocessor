## ------------------------------------------------------------
## Clock
## ------------------------------------------------------------
set_property PACKAGE_PIN W5  [get_ports Clk]
    set_property IOSTANDARD LVCMOS33 [get_ports Clk]
    create_clock -add -name sys_clk_pin -period 10.00 -waveform {0 5} [get_ports Clk]

## ------------------------------------------------------------
## Reset
## ------------------------------------------------------------
set_property PACKAGE_PIN U18 [get_ports Reset]
    set_property IOSTANDARD LVCMOS33 [get_ports Reset]

## ------------------------------------------------------------
## 7-Segment Display - segments  (active low)
## ------------------------------------------------------------
set_property PACKAGE_PIN W7  [get_ports {Seg7_out[0]}]
    set_property IOSTANDARD LVCMOS33 [get_ports {Seg7_out[0]}]
set_property PACKAGE_PIN W6  [get_ports {Seg7_out[1]}]
    set_property IOSTANDARD LVCMOS33 [get_ports {Seg7_out[1]}]
set_property PACKAGE_PIN U8  [get_ports {Seg7_out[2]}]
    set_property IOSTANDARD LVCMOS33 [get_ports {Seg7_out[2]}]
set_property PACKAGE_PIN V8  [get_ports {Seg7_out[3]}]
    set_property IOSTANDARD LVCMOS33 [get_ports {Seg7_out[3]}]
set_property PACKAGE_PIN U5  [get_ports {Seg7_out[4]}]
    set_property IOSTANDARD LVCMOS33 [get_ports {Seg7_out[4]}]
set_property PACKAGE_PIN V5  [get_ports {Seg7_out[5]}]
    set_property IOSTANDARD LVCMOS33 [get_ports {Seg7_out[5]}]
set_property PACKAGE_PIN U7  [get_ports {Seg7_out[6]}]
    set_property IOSTANDARD LVCMOS33 [get_ports {Seg7_out[6]}]

## ------------------------------------------------------------
## 7-Segment Display - anodes  (active low)
## ------------------------------------------------------------
set_property PACKAGE_PIN U2  [get_ports {Anode[0]}]
    set_property IOSTANDARD LVCMOS33 [get_ports {Anode[0]}]
set_property PACKAGE_PIN U4  [get_ports {Anode[1]}]
    set_property IOSTANDARD LVCMOS33 [get_ports {Anode[1]}]
set_property PACKAGE_PIN V4  [get_ports {Anode[2]}]
    set_property IOSTANDARD LVCMOS33 [get_ports {Anode[2]}]
set_property PACKAGE_PIN W4  [get_ports {Anode[3]}]
    set_property IOSTANDARD LVCMOS33 [get_ports {Anode[3]}]

## ------------------------------------------------------------
## LD0-LD3  :  R7 value (4-bit binary)
## ------------------------------------------------------------
set_property PACKAGE_PIN U16 [get_ports {R7[0]}]
    set_property IOSTANDARD LVCMOS33 [get_ports {R7[0]}]
set_property PACKAGE_PIN E19 [get_ports {R7[1]}]
    set_property IOSTANDARD LVCMOS33 [get_ports {R7[1]}]
set_property PACKAGE_PIN U19 [get_ports {R7[2]}]
    set_property IOSTANDARD LVCMOS33 [get_ports {R7[2]}]
set_property PACKAGE_PIN V19 [get_ports {R7[3]}]
    set_property IOSTANDARD LVCMOS33 [get_ports {R7[3]}]

## ------------------------------------------------------------
## LD4-LD5  :  ALU flags
## ------------------------------------------------------------
set_property PACKAGE_PIN W18 [get_ports Overflow]
    set_property IOSTANDARD LVCMOS33 [get_ports Overflow]
set_property PACKAGE_PIN U15 [get_ports Zero]
    set_property IOSTANDARD LVCMOS33 [get_ports Zero]

## ------------------------------------------------------------
## LD6-LD8  :  Feature 1 - Comparator
## ------------------------------------------------------------
set_property PACKAGE_PIN U14 [get_ports Equal]
    set_property IOSTANDARD LVCMOS33 [get_ports Equal]
set_property PACKAGE_PIN V14 [get_ports Less]
    set_property IOSTANDARD LVCMOS33 [get_ports Less]
set_property PACKAGE_PIN V13 [get_ports Greater]
    set_property IOSTANDARD LVCMOS33 [get_ports Greater]

## ------------------------------------------------------------
## LD9-LD10 :  Feature 3 - Parity Generator
## ------------------------------------------------------------
set_property PACKAGE_PIN V3  [get_ports Even_Parity]
    set_property IOSTANDARD LVCMOS33 [get_ports Even_Parity]
set_property PACKAGE_PIN W3  [get_ports Odd_Parity]
    set_property IOSTANDARD LVCMOS33 [get_ports Odd_Parity]

## ------------------------------------------------------------
## LD11-LD13 : Feature 4 - Magnitude Detector
## ------------------------------------------------------------
set_property PACKAGE_PIN U3  [get_ports Is_Zero]
    set_property IOSTANDARD LVCMOS33 [get_ports Is_Zero]
set_property PACKAGE_PIN P3  [get_ports Is_Small]
    set_property IOSTANDARD LVCMOS33 [get_ports Is_Small]
set_property PACKAGE_PIN N3  [get_ports Is_Large]
    set_property IOSTANDARD LVCMOS33 [get_ports Is_Large]

## ------------------------------------------------------------
## LD14-LD15 : Feature 2 - Multiplier
## ------------------------------------------------------------
set_property PACKAGE_PIN P1  [get_ports Mult_OV]
    set_property IOSTANDARD LVCMOS33 [get_ports Mult_OV]
set_property PACKAGE_PIN L1  [get_ports Mult_Result]
    set_property IOSTANDARD LVCMOS33 [get_ports Mult_Result]