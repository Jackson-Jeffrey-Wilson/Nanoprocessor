library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Program_ROM is
    Port ( address : in  STD_LOGIC_VECTOR(2 downto 0);
           data    : out STD_LOGIC_VECTOR(11 downto 0));
end Program_ROM;

architecture Behavioral of Program_ROM is

    type rom_type is array (0 to 7) of std_logic_vector(11 downto 0);

    signal ROM_DATA : rom_type := (
        0 => "101110000011",
        1 => "100100000011",
        2 => "001110100101",
        3 => "100110000101",
        4 => "101000000010",
        5 => "000111000000",
        6 => "011110000000",
        7 => "110000000000"
    );

begin
    data <= ROM_DATA(to_integer(unsigned(address)));
end Behavioral;