library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Multiplier_4_bit is
    Port (
        Input_A  : in  STD_LOGIC_VECTOR (3 downto 0);
        Input_B  : in  STD_LOGIC_VECTOR (3 downto 0);
        Result   : out STD_LOGIC_VECTOR (3 downto 0);
        Overflow : out STD_LOGIC
    );
end Multiplier_4_bit;

architecture Behavioral of Multiplier_4_bit is
    signal full_product : unsigned(7 downto 0);
begin
    full_product <= unsigned(Input_A) * unsigned(Input_B);
    Result   <= std_logic_vector(full_product(3 downto 0));
    Overflow <= '1' when full_product(7 downto 4) /= "0000" else '0';
end Behavioral;
