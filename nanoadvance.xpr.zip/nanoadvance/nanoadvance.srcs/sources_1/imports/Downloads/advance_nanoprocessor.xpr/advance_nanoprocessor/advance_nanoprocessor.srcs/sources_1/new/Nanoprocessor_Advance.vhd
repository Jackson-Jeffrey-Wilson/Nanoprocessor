library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Nanoprocessor_Advance is
    Port (
        Clk         : in  STD_LOGIC;
        Reset       : in  STD_LOGIC;
        Overflow    : out STD_LOGIC;
        Zero        : out STD_LOGIC;
        Equal       : out STD_LOGIC;
        Less        : out STD_LOGIC;
        Greater     : out STD_LOGIC;
        Even_Parity : out STD_LOGIC;
        Odd_Parity  : out STD_LOGIC;
        Is_Zero     : out STD_LOGIC;
        Is_Small    : out STD_LOGIC;
        Is_Large    : out STD_LOGIC;
        Mult_OV     : out STD_LOGIC;
        Mult_Result : out STD_LOGIC;    
        R7          : out STD_LOGIC_VECTOR(3 downto 0);
        Seg7_out    : out STD_LOGIC_VECTOR(6 downto 0);
        Anode       : out STD_LOGIC_VECTOR(3 downto 0)
    );
end Nanoprocessor_Advance;

architecture Behavioral of Nanoprocessor_Advance is

    component LUT_16_7
        Port (
            Data     : in  STD_LOGIC_VECTOR(3 downto 0);
            Seg7_out : out STD_LOGIC_VECTOR(6 downto 0);
            Anode    : out STD_LOGIC_VECTOR(3 downto 0)
        );
    end component;

    component Slow_Clk
        Port (
            Clk_in  : in  STD_LOGIC;
            Clk_out : out STD_LOGIC
        );
    end component;

    component Register_Bank
        Port (
            Reg_en                   : in  STD_LOGIC_VECTOR(2 downto 0);
            Clk                      : in  STD_LOGIC;
            Reset                    : in  STD_LOGIC;
            Inp                      : in  STD_LOGIC_VECTOR(3 downto 0);
            Q0,Q1,Q2,Q3,Q4,Q5,Q6,Q7 : out STD_LOGIC_VECTOR(3 downto 0)
        );
    end component;

    component MUX_8_way_4_Bit
        Port (
            Reg_Sel                  : in  STD_LOGIC_VECTOR(2 downto 0);
            R0,R1,R2,R3,R4,R5,R6,R7 : in  STD_LOGIC_VECTOR(3 downto 0);
            Q                        : out STD_LOGIC_VECTOR(3 downto 0)
        );
    end component;

    component ALU
        Port (
            A, B        : in  STD_LOGIC_VECTOR(3 downto 0);
            Operation   : in  STD_LOGIC_VECTOR(2 downto 0);
            Result      : out STD_LOGIC_VECTOR(3 downto 0);
            Zero        : out STD_LOGIC;
            Overflow    : out STD_LOGIC;
            Equal       : out STD_LOGIC;
            LessThan    : out STD_LOGIC;
            GreaterThan : out STD_LOGIC
        );
    end component;

    component MUX_2_way_4_Bit
        Port (
            Adder_Sub_Out : in  STD_LOGIC_VECTOR(3 downto 0);
            Imd_Value     : in  STD_LOGIC_VECTOR(3 downto 0);
            Load          : in  STD_LOGIC;
            Q             : out STD_LOGIC_VECTOR(3 downto 0)
        );
    end component;

    component MUX_2_way_3_Bit
        Port (
            Adder_out : in  STD_LOGIC_VECTOR(2 downto 0);
            Address   : in  STD_LOGIC_VECTOR(2 downto 0);
            Jump      : in  STD_LOGIC;
            Q         : out STD_LOGIC_VECTOR(2 downto 0)
        );
    end component;

    component Instuction_Decoder
        Port (
            Instruction      : in  STD_LOGIC_VECTOR(11 downto 0);
            Reg_Check_Jmp    : in  STD_LOGIC_VECTOR(3 downto 0);
            Reg_en           : out STD_LOGIC_VECTOR(2 downto 0);
            Load_sel         : out STD_LOGIC;
            Imd_Val          : out STD_LOGIC_VECTOR(3 downto 0);
            Reg_Sel_A        : out STD_LOGIC_VECTOR(2 downto 0);
            Reg_Sel_B        : out STD_LOGIC_VECTOR(2 downto 0);
            Operation_Select : out STD_LOGIC_VECTOR(2 downto 0);
            Jump_address     : out STD_LOGIC_VECTOR(2 downto 0);
            Jump_flag        : out STD_LOGIC
        );
    end component;

    component Program_ROM
        Port (
            address : in  STD_LOGIC_VECTOR(2 downto 0);
            data    : out STD_LOGIC_VECTOR(11 downto 0)
        );
    end component;

    component Program_Counter
        Port (
            D     : in  STD_LOGIC_VECTOR(2 downto 0);
            En    : in  STD_LOGIC;
            Reset : in  STD_LOGIC;
            Clk   : in  STD_LOGIC;
            Q     : out STD_LOGIC_VECTOR(2 downto 0)
        );
    end component;

    component Adder_3_Bit
        Port (
            A     : in  STD_LOGIC_VECTOR(2 downto 0);
            C_in  : in  STD_LOGIC;
            S     : out STD_LOGIC_VECTOR(2 downto 0);
            C_out : out STD_LOGIC
        );
    end component;

    component Multiplier_4_bit
        Port (
            Input_A  : in  STD_LOGIC_VECTOR(3 downto 0);
            Input_B  : in  STD_LOGIC_VECTOR(3 downto 0);
            Result   : out STD_LOGIC_VECTOR(3 downto 0);
            Overflow : out STD_LOGIC
        );
    end component;

    component Parity_Generator
        Port (
            Data_In     : in  STD_LOGIC_VECTOR(3 downto 0);
            Even_Parity : out STD_LOGIC;
            Odd_Parity  : out STD_LOGIC
        );
    end component;

    component Magnitude_Detector
        Port (
            Data_In  : in  STD_LOGIC_VECTOR(3 downto 0);
            Is_Zero  : out STD_LOGIC;
            Is_Small : out STD_LOGIC;
            Is_Large : out STD_LOGIC
        );
    end component;

    signal Imd_Val_sig, ALU_Out_Bus, Data_Mux_to_Reg_Bank : STD_LOGIC_VECTOR(3 downto 0);
    signal Data_bus0, Data_bus1, Data_bus2, Data_bus3,
           Data_bus4, Data_bus5, Data_bus6, Data_bus7     : STD_LOGIC_VECTOR(3 downto 0);
    signal Ins_Bus                                         : STD_LOGIC_VECTOR(11 downto 0);
    signal Mem_Bus, Count_Mux_to_PC,
           Mem_RCA3_to_Mux, Jump_Add                      : STD_LOGIC_VECTOR(2 downto 0);
    signal Reg_bus, Reg_SelA, Reg_SelB, Op_Sel            : STD_LOGIC_VECTOR(2 downto 0);
    signal Load_Select, Jump_Flag, slow_clock              : STD_LOGIC;
    signal Mux_A_out, Mux_B_out                           : STD_LOGIC_VECTOR(3 downto 0);
    signal Carry_Flag, Zero_Flag,
           Eq_Flag, Lt_Flag, Gt_Flag                      : STD_LOGIC;
    signal Mult_Result_internal                            : STD_LOGIC_VECTOR(3 downto 0);
    signal Mult_OV_internal                                : STD_LOGIC;
    signal Odd_Parity_internal                             : STD_LOGIC;
    signal Is_Large_internal                               : STD_LOGIC;

begin

    LUT_16_7_0 : LUT_16_7
        port map (
            Data     => Data_bus7,
            Seg7_out => Seg7_out,
            Anode    => Anode
        );

    Slow_Clk_0 : Slow_Clk
        port map (
            Clk_in  => Clk,
            Clk_out => slow_clock
        );

    ROM_0 : Program_ROM
        port map (
            address => Mem_Bus,
            data    => Ins_Bus
        );

    Program_Counter_0 : Program_Counter
        port map (
            D     => Count_Mux_to_PC,
            En    => '1',
            Reset => Reset,
            Clk   => slow_clock,
            Q     => Mem_Bus
        );

    Instuction_Decoder_0 : Instuction_Decoder
        port map (
            Instruction      => Ins_Bus,
            Reg_en           => Reg_bus,
            Load_sel         => Load_Select,
            Imd_Val          => Imd_Val_sig,
            Reg_Sel_A        => Reg_SelA,
            Reg_Sel_B        => Reg_SelB,
            Operation_Select => Op_Sel,
            Jump_address     => Jump_Add,
            Jump_flag        => Jump_Flag,
            Reg_Check_Jmp    => Mux_A_out
        );

    Register_Bank_0 : Register_Bank
        port map (
            Reg_en => Reg_bus,
            Clk    => slow_clock,
            Reset  => Reset,
            Inp    => Data_Mux_to_Reg_Bank,
            Q0     => Data_bus0, Q1 => Data_bus1,
            Q2     => Data_bus2, Q3 => Data_bus3,
            Q4     => Data_bus4, Q5 => Data_bus5,
            Q6     => Data_bus6, Q7 => Data_bus7
        );

    ALU_0 : ALU
        port map (
            A           => Mux_A_out,
            B           => Mux_B_out,
            Operation   => Op_Sel,
            Result      => ALU_Out_Bus,
            Zero        => Zero_Flag,
            Overflow    => Carry_Flag,
            Equal       => Eq_Flag,
            LessThan    => Lt_Flag,
            GreaterThan => Gt_Flag
        );

    MUX_2_way_4_Bit_0 : MUX_2_way_4_Bit
        port map (
            Load          => Load_Select,
            Adder_Sub_Out => ALU_Out_Bus,
            Imd_Value     => Imd_Val_sig,
            Q             => Data_Mux_to_Reg_Bank
        );

    MUX_8_way_4_Bit_A : MUX_8_way_4_Bit
        port map (
            Reg_Sel => Reg_SelA,
            R0 => Data_bus0, R1 => Data_bus1,
            R2 => Data_bus2, R3 => Data_bus3,
            R4 => Data_bus4, R5 => Data_bus5,
            R6 => Data_bus6, R7 => Data_bus7,
            Q  => Mux_A_out
        );

    MUX_8_way_4_Bit_B : MUX_8_way_4_Bit
        port map (
            Reg_Sel => Reg_SelB,
            R0 => Data_bus0, R1 => Data_bus1,
            R2 => Data_bus2, R3 => Data_bus3,
            R4 => Data_bus4, R5 => Data_bus5,
            R6 => Data_bus6, R7 => Data_bus7,
            Q  => Mux_B_out
        );

    Adder_3_Bit_0 : Adder_3_Bit
        port map (
            A     => Mem_Bus,
            C_in  => '0',
            S     => Mem_RCA3_to_Mux,
            C_out => open
        );

    MUX_2_way_3_Bit_0 : MUX_2_way_3_Bit
        port map (
            Jump      => Jump_Flag,
            Adder_out => Mem_RCA3_to_Mux,
            Address   => Jump_Add,
            Q         => Count_Mux_to_PC
        );

    Multiplier_top : Multiplier_4_bit
        port map (
            Input_A  => Mux_A_out,
            Input_B  => Mux_B_out,
            Result   => Mult_Result_internal,
            Overflow => Mult_OV_internal
        );

    Parity_Generator_0 : Parity_Generator
        port map (
            Data_In     => Data_bus7,
            Even_Parity => Even_Parity,
            Odd_Parity  => Odd_Parity_internal
        );

    Magnitude_Detector_0 : Magnitude_Detector
        port map (
            Data_In  => Data_bus7,
            Is_Zero  => Is_Zero,
            Is_Small => Is_Small,
            Is_Large => Is_Large_internal
        );

    Overflow    <= Carry_Flag;
    Zero        <= Zero_Flag;
    Equal       <= Eq_Flag;
    Less        <= Lt_Flag;
    Greater     <= Gt_Flag;
    R7          <= Data_bus7;

    Mult_Result <= Mult_Result_internal(0);
    Mult_OV     <= Mult_OV_internal;

    Odd_Parity  <= Odd_Parity_internal;

    Is_Large    <= Is_Large_internal;

end Behavioral;