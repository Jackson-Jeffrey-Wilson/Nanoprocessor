library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Add_Sub_4_bit is
    Port (
        Input_A       : in  STD_LOGIC_VECTOR (3 downto 0);
        Input_B       : in  STD_LOGIC_VECTOR (3 downto 0);
        Mode_Sel      : in  STD_LOGIC;
        Result        : out STD_LOGIC_VECTOR (3 downto 0);
        Overflow_Flag : out STD_LOGIC
    );
end Add_Sub_4_bit;

architecture Behavioral of Add_Sub_4_bit is
    signal B_eff  : STD_LOGIC_VECTOR(3 downto 0);
    signal carry  : STD_LOGIC_VECTOR(4 downto 0);
    signal sum_int : STD_LOGIC_VECTOR(3 downto 0);

    component FA
        Port (
            A     : in  STD_LOGIC;
            B     : in  STD_LOGIC;
            C_in  : in  STD_LOGIC;
            S     : out STD_LOGIC;
            C_out : out STD_LOGIC
        );
    end component;

begin
    B_eff(0) <= Input_B(0) XOR Mode_Sel;
    B_eff(1) <= Input_B(1) XOR Mode_Sel;
    B_eff(2) <= Input_B(2) XOR Mode_Sel;
    B_eff(3) <= Input_B(3) XOR Mode_Sel;

    carry(0) <= Mode_Sel;

    FA0 : FA port map (A => Input_A(0), B => B_eff(0), C_in => carry(0), S => sum_int(0), C_out => carry(1));
    FA1 : FA port map (A => Input_A(1), B => B_eff(1), C_in => carry(1), S => sum_int(1), C_out => carry(2));
    FA2 : FA port map (A => Input_A(2), B => B_eff(2), C_in => carry(2), S => sum_int(2), C_out => carry(3));
    FA3 : FA port map (A => Input_A(3), B => B_eff(3), C_in => carry(3), S => sum_int(3), C_out => carry(4));

    Result        <= sum_int;
    Overflow_Flag <= carry(3) XOR carry(4);

end Behavioral;