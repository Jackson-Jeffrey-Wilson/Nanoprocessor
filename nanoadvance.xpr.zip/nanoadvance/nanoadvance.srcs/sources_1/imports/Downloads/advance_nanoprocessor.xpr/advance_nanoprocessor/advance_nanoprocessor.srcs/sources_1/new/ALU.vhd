library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity ALU is
    Port (
        A, B        : in  STD_LOGIC_VECTOR(3 downto 0);
        Operation   : in  STD_LOGIC_VECTOR(2 downto 0);
        Result      : out STD_LOGIC_VECTOR(3 downto 0);
        Zero        : out STD_LOGIC;
        Overflow    : out STD_LOGIC;
        Equal       : out STD_LOGIC;
        LessThan    : out STD_LOGIC;
        GreaterThan : out STD_LOGIC
    );
end ALU;

architecture Behavioral of ALU is

    component Add_Sub_4_bit
        Port (
            Input_A, Input_B : in  STD_LOGIC_VECTOR(3 downto 0);
            Mode_Sel         : in  STD_LOGIC;
            Result           : out STD_LOGIC_VECTOR(3 downto 0);
            Overflow_Flag    : out STD_LOGIC
        );
    end component;

    component Comparator_4_bit
        Port (
            Input_A, Input_B : in  STD_LOGIC_VECTOR(3 downto 0);
            Equal_Flag       : out STD_LOGIC;
            LessThan_Flag    : out STD_LOGIC;
            GreaterThan_Flag : out STD_LOGIC
        );
    end component;

    component Multiplier_4_bit
        Port (
            Input_A, Input_B : in  STD_LOGIC_VECTOR(3 downto 0);
            Result           : out STD_LOGIC_VECTOR(3 downto 0);
            Overflow         : out STD_LOGIC
        );
    end component;

    signal AS_Res, Mul_Res : STD_LOGIC_VECTOR(3 downto 0);
    signal Sel_A, Sel_B    : STD_LOGIC_VECTOR(3 downto 0);
    signal AS_Mode         : STD_LOGIC;
    signal Mul_OV_internal : STD_LOGIC;

begin

    Sel_A   <= "0000" when Operation = "111" else A;
    Sel_B   <= A      when Operation = "111" else B;
    AS_Mode <= '1'    when (Operation = "001" or Operation = "111") else '0';

    AS_Unit : Add_Sub_4_bit
        port map (
            Input_A       => Sel_A,
            Input_B       => Sel_B,
            Mode_Sel      => AS_Mode,
            Result        => AS_Res,
            Overflow_Flag => Overflow
        );

    Comp_Unit : Comparator_4_bit
        port map (
            Input_A          => A,
            Input_B          => B,
            Equal_Flag       => Equal,
            LessThan_Flag    => LessThan,
            GreaterThan_Flag => GreaterThan
        );

    Mul_Unit : Multiplier_4_bit
        port map (
            Input_A  => A,
            Input_B  => B,
            Result   => Mul_Res,
            Overflow => Mul_OV_internal
        );

    process(Operation, AS_Res, Mul_Res, A, B)
    begin
        case Operation is
            when "000" | "001" | "111" => Result <= AS_Res;
            when "101"                 => Result <= Mul_Res;
            when "010"                 => Result <= A and B;
            when "011"                 => Result <= A or  B;
            when "100"                 => Result <= A xor B;
            when others                => Result <= "0000";
        end case;
    end process;

    Zero <= '1' when AS_Res = "0000" else '0';

end Behavioral;