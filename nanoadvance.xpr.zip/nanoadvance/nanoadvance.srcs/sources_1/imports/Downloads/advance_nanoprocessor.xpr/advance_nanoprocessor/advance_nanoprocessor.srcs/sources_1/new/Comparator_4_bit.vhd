library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Comparator_4_bit is
    Port (
        Input_A          : in  STD_LOGIC_VECTOR (3 downto 0);
        Input_B          : in  STD_LOGIC_VECTOR (3 downto 0);
        Equal_Flag       : out STD_LOGIC;
        LessThan_Flag    : out STD_LOGIC;
        GreaterThan_Flag : out STD_LOGIC
    );
end Comparator_4_bit;

architecture Behavioral of Comparator_4_bit is
begin
    process(Input_A, Input_B)
    begin
        Equal_Flag       <= '0';
        LessThan_Flag    <= '0';
        GreaterThan_Flag <= '0';
        if (unsigned(Input_A) = unsigned(Input_B)) then
            Equal_Flag <= '1';
        elsif (unsigned(Input_A) < unsigned(Input_B)) then
            LessThan_Flag <= '1';
        else
            GreaterThan_Flag <= '1';
        end if;
    end process;
end Behavioral;