library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Instuction_Decoder is
    Port (
        Instruction      : in  STD_LOGIC_VECTOR(11 downto 0);
        Reg_Check_Jmp    : in  STD_LOGIC_VECTOR(3 downto 0);
        Reg_en           : out STD_LOGIC_VECTOR(2 downto 0);
        Load_sel         : out STD_LOGIC;
        Imd_Val          : out STD_LOGIC_VECTOR(3 downto 0);
        Reg_Sel_A        : out STD_LOGIC_VECTOR(2 downto 0);
        Reg_Sel_B        : out STD_LOGIC_VECTOR(2 downto 0);
        Operation_Select : out STD_LOGIC_VECTOR(2 downto 0);
        Jump_address     : out STD_LOGIC_VECTOR(2 downto 0);
        Jump_flag        : out STD_LOGIC
    );
end Instuction_Decoder;

architecture Behavioral of Instuction_Decoder is
begin

    process(Instruction, Reg_Check_Jmp)
        variable Opcode : STD_LOGIC_VECTOR(1 downto 0);
        variable SubOp  : STD_LOGIC_VECTOR(3 downto 0);
    begin
        Opcode := Instruction(11 downto 10);
        SubOp  := Instruction(3 downto 0);

        Jump_flag        <= '0';
        Reg_en           <= "000";
        Load_sel         <= '0';
        Operation_Select <= "000";
        Reg_Sel_A        <= Instruction(9 downto 7);
        Reg_Sel_B        <= Instruction(6 downto 4);
        Imd_Val          <= Instruction(3 downto 0);
        Jump_address     <= Instruction(2 downto 0);

        case Opcode is

            when "10" =>
                Reg_en   <= Instruction(9 downto 7);
                Load_sel <= '1';

            when "00" =>
                Reg_en   <= Instruction(9 downto 7);
                Load_sel <= '0';
                case SubOp is
                    when "0000" => Operation_Select <= "000";
                    when "0001" => Operation_Select <= "001";
                    when "0101" => Operation_Select <= "101";
                    when "0110" => Operation_Select <= "110";
                    when others => Operation_Select <= "000";
                end case;

            when "01" =>
                Reg_en           <= Instruction(9 downto 7);
                Load_sel         <= '0';
                Operation_Select <= "111";

            when "11" =>
                if Reg_Check_Jmp = "0000" then
                    Jump_flag <= '1';
                end if;

            when others => null;

        end case;
    end process;

end Behavioral;