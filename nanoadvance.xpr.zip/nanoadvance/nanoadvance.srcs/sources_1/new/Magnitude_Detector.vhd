library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Magnitude_Detector is
    Port (
        Data_In    : in  STD_LOGIC_VECTOR (3 downto 0);
        Is_Zero    : out STD_LOGIC;
        Is_Small   : out STD_LOGIC;
        Is_Large   : out STD_LOGIC
    );
end Magnitude_Detector;

architecture Behavioral of Magnitude_Detector is
begin
    process(Data_In)
    begin
        Is_Zero  <= '0';
        Is_Small <= '0';
        Is_Large <= '0';
        if unsigned(Data_In) = 0 then
            Is_Zero <= '1';
        elsif unsigned(Data_In) <= 7 then
            Is_Small <= '1';
        else
            Is_Large <= '1';
        end if;
    end process;
end Behavioral;