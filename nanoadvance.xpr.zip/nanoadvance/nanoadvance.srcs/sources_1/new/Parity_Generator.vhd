library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Parity_Generator is
    Port (
        Data_In    : in  STD_LOGIC_VECTOR (3 downto 0);
        Even_Parity : out STD_LOGIC;
        Odd_Parity  : out STD_LOGIC
    );
end Parity_Generator;

architecture Behavioral of Parity_Generator is
    signal xor_chain : STD_LOGIC;
begin
    xor_chain  <= Data_In(3) XOR Data_In(2) XOR Data_In(1) XOR Data_In(0);
    Even_Parity <= NOT xor_chain;
    Odd_Parity  <= xor_chain;
end Behavioral;